package com.worldline.interview;

public enum FuelType {
    PETROL, DIESEL, WOOD, COAL
    //新增 wood coal
}
